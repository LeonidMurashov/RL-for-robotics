def atari():
    return dict(
        lrschedule='constant'
    )
